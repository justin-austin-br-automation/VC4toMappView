#!/bin/bash
#######
# Copies the content of the USB install stick to the linux filesystem "/root"
#######

SETUP_DIR=$1
SETUPFILES_DIR=$SETUP_DIR"/SetupFiles"
SETUP_BASEAR_DIR=$SETUPFILES_DIR"/BaseAR"
SETUP_SCRIPTS_DIR=$SETUPFILES_DIR"/scripts"
SETUP_GRUB_DIR=$SETUP_DIR"/grub"

ROOT_DIR="/root"
ROOT_BASEAR_DIR=$ROOT_DIR"/BaseAR"
ROOT_SCRIPTS_DIR=$ROOT_DIR"/scripts"
ROOT_GRUB_DIR=$ROOT_DIR"/grub"

mkdir -p $ROOT_BASEAR_DIR
mkdir -p $ROOT_SCRIPTS_DIR
mkdir -p $ROOT_GRUB_DIR

cp -f $SETUP_SCRIPTS_DIR/* $ROOT_SCRIPTS_DIR
chmod u+x $ROOT_SCRIPTS_DIR/*

cp -f -r $SETUP_BASEAR_DIR/*  $ROOT_BASEAR_DIR
if [ -d $SETUP_GRUB_DIR ] ; then  
  cp -f -r $SETUP_GRUB_DIR/* $ROOT_GRUB_DIR
fi
